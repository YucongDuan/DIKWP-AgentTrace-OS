# Code of Conduct

Use this project to improve AI transparency, safety, reliability, and accountability. Do not use it to hide, manipulate, or coerce.
