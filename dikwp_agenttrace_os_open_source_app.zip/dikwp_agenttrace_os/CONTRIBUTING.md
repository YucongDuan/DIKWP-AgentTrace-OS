# Contributing

Contributions should preserve the project boundary: defensive audit, semantic observability, and replayability only.

Do not contribute code that implements host-level persistence, process injection, privilege escalation, hidden replication, sandbox escape, credential capture, or evasion.
