# Security Policy

Report security issues privately to the project maintainers. This project intentionally avoids network calls, subprocess execution, host mutation, and invasive telemetry.
