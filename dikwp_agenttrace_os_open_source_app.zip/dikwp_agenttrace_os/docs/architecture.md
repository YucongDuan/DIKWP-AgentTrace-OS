# Architecture

DIKWP AgentTrace OS has five layers.

## 1. Ingestion Layer

Input is a JSON agent run log. Each event contains `event_id`, `timestamp`, `event_type`, `actor`, `content`, optional `tool_name`, optional references, and metadata. This is intentionally simple so other frameworks can export to the format.

## 2. Semantic Registration Layer

Each event is registered as `C=(D,I,K,W,P,R)`:

- D: raw trace data, event type, actor, token estimate, redacted content.
- I: event relation, tool binding, retrieval source, memory scope.
- K: operational knowledge such as RAG evidence requirements, memory governance, tool boundary.
- W: action wisdom such as reversibility, consent, retention, least privilege, residual.
- P: local purpose and no-ultimate-purpose guard.
- R: reliability, borrowed reliability, and support-scope caveat.

## 3. Risk Signal Layer

Detectors scan for:

- prompt injection and audit suppression
- sensitive data exposure
- unapproved tools
- tool overreach
- unbounded memory
- memory poisoning
- purpose drift
- evidence gaps
- unsupported certainty

## 4. Custody and Replay Layer

The system builds a hash chain across redacted events. The hash chain is not a substitute for a production ledger or trusted timestamping service, but it provides a local tamper-evident custody primitive.

The replay bundle contains redacted events, metadata, hash chain, and decision summary.

## 5. Interop Layer

The tool exports OpenTelemetry-style spans. It does not claim to implement the full OpenTelemetry specification in this prototype; it provides a bridge shape for later OTEL integration.
