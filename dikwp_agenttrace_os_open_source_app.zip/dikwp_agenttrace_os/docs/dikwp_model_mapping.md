# DIKWP Model Mapping

## Event object

Every event is compiled into:

```text
C = (D, I, K, W, P, R)
```

## Example: tool call

- D: tool name, arguments, actor, timestamp.
- I: relation to prior input and downstream output.
- K: tool policy, approval requirement, blast radius.
- W: reversibility, cost bearer, user consent, least privilege.
- P: task purpose and potential purpose drift.
- R: tool output reliability and borrowed reliability label.

## Example: memory write

- D: proposed memory content.
- I: memory scope, retention, user/context relation.
- K: memory usage rule.
- W: privacy, consent, poisoning risk, deletion path.
- P: allowed future purpose.
- R: source evidence, TTL, review requirement.

## Example: final output

- D: text output.
- I: references to retrieval and tool results.
- K: claim-to-evidence mapping requirement.
- W: unsupported certainty and action boundary.
- P: intended user outcome.
- R: provisional until proof ledger review.
