# Release v0.1.0 Draft

DIKWP AgentTrace OS v0.1.0 is now available.

This release introduces an open-source AI agent black-box recorder and semantic trace ledger. It ingests agent run JSON, builds DIKWP event records, detects runtime risks, generates a hash-chain replay bundle, and exports OpenTelemetry-style spans.

Highlights:

- DIKWP Event Ledger
- Prompt injection and audit-suppression detection
- Tool overreach detection
- Memory risk detection
- Purpose drift detection
- Evidence gap detection
- Replay bundle
- Static boundary audit
