# Governance Boundary

DIKWP AgentTrace OS is for transparency, auditing, debugging, and governance.

It is not for covert surveillance, employee monitoring without notice, credential capture, hidden logging, or evasion.

## Required deployment principles

- Notify users and operators that agent traces are recorded.
- Redact secrets before storage.
- Apply retention limits.
- Restrict access to replay bundles.
- Preserve human review for high-impact actions.
- Do not treat hash chains as a substitute for full compliance controls.

## Kill conditions

- Trace logging is used covertly against people.
- Replay bundles include secrets without redaction.
- Agent action traces are deleted to hide harm.
- The tool is modified to perform host-level persistence, evasion, or external exfiltration.
- The model's post-hoc explanation is treated as more authoritative than the event ledger.
