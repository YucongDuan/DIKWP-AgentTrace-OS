# Integration Guide

## Input format

Export agent events as JSON:

```json
{
  "trace_id": "run-001",
  "events": [
    {
      "event_id": "e001",
      "timestamp": "2026-05-09T10:00:00Z",
      "event_type": "user_input",
      "actor": "user",
      "content": "...",
      "metadata": {"purpose": "..."}
    }
  ]
}
```

## Supported event types

- `user_input`
- `model_call`
- `retrieval`
- `tool_call`
- `tool_result`
- `memory_write`
- `final_output`

## Integration points

- Use before incident review.
- Run after every high-impact agent workflow.
- Export `otel_style_spans.json` into an observability backend.
- Feed final output to DIKWP ProofLedger OS.
- Feed memory writes to DIKWP MemoryLedger OS.
- Feed next run pre-actions to DIKWP IntentGuard OS.
