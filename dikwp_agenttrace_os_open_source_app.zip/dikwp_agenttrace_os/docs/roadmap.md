# Roadmap

## v0.2

- JSONL streaming trace ingestion.
- More precise OpenTelemetry semantic convention support.
- Claim-to-evidence linking with ProofLedger OS.
- Memory write export to MemoryLedger OS.

## v0.3

- Agent framework adapters.
- Redaction policy engine.
- Run-level comparison and regression testing.
- Incident severity templates.

## v1.0

- Production-grade dashboard.
- Signed trace bundles.
- Policy-as-code.
- Enterprise SSO and retention controls.
