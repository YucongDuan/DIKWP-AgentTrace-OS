# Incident Recommendations

Trace ID: `demo-agent-run-2026-05-09-001`
Decision: `block_or_human_review_required`
Risk score: `0.7886`

## Priority actions
- `prompt_injection_or_audit_suppression`: 1 finding(s). Review associated events and apply recovery path.
- `purpose_drift`: 2 finding(s). Review associated events and apply recovery path.
- `sensitive_data_exposure`: 1 finding(s). Review associated events and apply recovery path.
- `tool_overreach`: 1 finding(s). Review associated events and apply recovery path.
- `unapproved_tool`: 1 finding(s). Review associated events and apply recovery path.
- `unsupported_certainty`: 1 finding(s). Review associated events and apply recovery path.

## DIKWP boundary
- Do not rely on the model's post-hoc explanation alone.
- Reconstruct the run from the replay bundle and hash chain.
- Use ProofLedger for final-output claims, MemoryLedger for memory writes, and IntentGuard for future pre-execution blocking.
