from __future__ import annotations

import csv
import json
from collections import Counter
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List, Tuple

from .dikwp import register_event
from .ledger import build_hash_chain, chain_root
from .models import AgentEvent, TraceReport
from .signals import detect_risks, summarize_findings
from .text_utils import redact, estimate_token_count

SYSTEM = "DIKWP AgentTrace OS"
VERSION = "0.1.0"


def load_events(path: str | Path) -> Tuple[str, List[AgentEvent]]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    trace_id = raw.get("trace_id", "trace-local-001")
    events = []
    for item in raw.get("events", []):
        events.append(AgentEvent(
            event_id=str(item.get("event_id")),
            timestamp=str(item.get("timestamp", "")),
            event_type=str(item.get("event_type", "event")),
            actor=str(item.get("actor", "unknown")),
            content=str(item.get("content", "")),
            tool_name=item.get("tool_name"),
            input_ref=item.get("input_ref"),
            output_ref=item.get("output_ref"),
            metadata=dict(item.get("metadata", {})),
        ))
    return trace_id, events


def load_policy(path: str | Path | None) -> Dict:
    if not path:
        return {}
    return json.loads(Path(path).read_text(encoding="utf-8"))


def analyze(input_path: str | Path, policy_path: str | Path | None, out_dir: str | Path) -> TraceReport:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    trace_id, events = load_events(input_path)
    policy = load_policy(policy_path)
    findings = detect_risks(events, policy)
    risk_score = min(1.0, sum(f.score for f in findings) / max(1, len(events)))
    decision = _decision_from_score(risk_score, findings)
    chain = build_hash_chain(events)
    dikwp_records = [register_event(e) for e in events]
    report = TraceReport(
        system=SYSTEM,
        version=VERSION,
        trace_id=trace_id,
        decision=decision,
        risk_score=round(risk_score, 4),
        event_count=len(events),
        risk_count=len(findings),
        hash_chain_root=chain_root(chain),
        event_type_counts=dict(Counter(e.event_type for e in events)),
        risk_category_counts=summarize_findings(findings),
        purpose_drift_score=_category_score(findings, "purpose_drift"),
        evidence_gap_score=_category_score(findings, "evidence_gap"),
        tool_overreach_score=_category_score(findings, "tool_overreach"),
        memory_risk_score=max(_category_score(findings, "unbounded_memory"), _category_score(findings, "memory_poisoning")),
        replayable=bool(events and chain),
        findings=findings,
    )

    (out / "agent_trace_report.json").write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "dikwp_event_ledger.json").write_text(json.dumps([asdict(r) for r in dikwp_records], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "replay_bundle.json").write_text(json.dumps(_replay_bundle(trace_id, events, chain, report), ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "otel_style_spans.json").write_text(json.dumps(_otel_spans(trace_id, events, chain), ensure_ascii=False, indent=2), encoding="utf-8")
    _write_timeline_csv(out / "trace_timeline.csv", events, chain)
    _write_risk_csv(out / "risk_events.csv", findings)
    (out / "incident_recommendations.md").write_text(_recommendations(report), encoding="utf-8")
    return report


def _category_score(findings, category: str) -> float:
    vals = [f.score for f in findings if f.category == category]
    return round(max(vals) if vals else 0.0, 4)


def _decision_from_score(score: float, findings) -> str:
    high = any(f.severity == "high" for f in findings)
    if score >= 0.6 or high:
        return "block_or_human_review_required"
    if score >= 0.25:
        return "review"
    return "allow"


def _replay_bundle(trace_id: str, events: List[AgentEvent], chain: List[Dict], report: TraceReport) -> Dict:
    return {
        "trace_id": trace_id,
        "system": SYSTEM,
        "version": VERSION,
        "hash_chain_root": report.hash_chain_root,
        "decision": report.decision,
        "events": [
            {
                "event_id": e.event_id,
                "timestamp": e.timestamp,
                "event_type": e.event_type,
                "actor": e.actor,
                "tool_name": e.tool_name,
                "content_redacted": redact(e.content),
                "metadata": e.metadata,
            }
            for e in events
        ],
        "hash_chain": chain,
        "replay_note": "Replay in timestamp order. Validate each event_hash against previous_hash before review.",
    }


def _otel_spans(trace_id: str, events: List[AgentEvent], chain: List[Dict]) -> List[Dict]:
    spans = []
    hash_by_id = {c["event_id"]: c["event_hash"] for c in chain}
    for idx, e in enumerate(events):
        spans.append({
            "trace_id": trace_id,
            "span_id": e.event_id,
            "parent_span_id": e.input_ref,
            "name": f"agent.{e.event_type}",
            "start_time": e.timestamp,
            "attributes": {
                "agent.actor": e.actor,
                "agent.event_type": e.event_type,
                "gen_ai.tool.name": e.tool_name,
                "dikwp.hash": hash_by_id.get(e.event_id),
                "dikwp.token_estimate": estimate_token_count(e.content),
                "dikwp.purpose": e.metadata.get("purpose") or e.metadata.get("task_purpose") or "not_explicit",
            },
        })
    return spans


def _write_timeline_csv(path: Path, events: List[AgentEvent], chain: List[Dict]) -> None:
    hash_by_id = {c["event_id"]: c["event_hash"] for c in chain}
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["event_id", "timestamp", "event_type", "actor", "tool_name", "token_estimate", "event_hash"])
        writer.writeheader()
        for e in events:
            writer.writerow({
                "event_id": e.event_id,
                "timestamp": e.timestamp,
                "event_type": e.event_type,
                "actor": e.actor,
                "tool_name": e.tool_name or "",
                "token_estimate": estimate_token_count(e.content),
                "event_hash": hash_by_id.get(e.event_id),
            })


def _write_risk_csv(path: Path, findings) -> None:
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["event_id", "category", "severity", "score", "reason", "recovery"])
        writer.writeheader()
        for r in findings:
            writer.writerow(asdict(r))


def _recommendations(report: TraceReport) -> str:
    lines = [
        "# Incident Recommendations",
        "",
        f"Trace ID: `{report.trace_id}`",
        f"Decision: `{report.decision}`",
        f"Risk score: `{report.risk_score}`",
        "",
        "## Priority actions",
    ]
    if report.risk_count == 0:
        lines.append("- No major findings. Preserve trace ledger and keep normal retention policy.")
    else:
        for cat, count in sorted(report.risk_category_counts.items()):
            lines.append(f"- `{cat}`: {count} finding(s). Review associated events and apply recovery path.")
    lines += [
        "",
        "## DIKWP boundary",
        "- Do not rely on the model's post-hoc explanation alone.",
        "- Reconstruct the run from the replay bundle and hash chain.",
        "- Use ProofLedger for final-output claims, MemoryLedger for memory writes, and IntentGuard for future pre-execution blocking.",
    ]
    return "\n".join(lines) + "\n"
