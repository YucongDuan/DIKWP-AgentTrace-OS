"""Optional Streamlit app placeholder.

Run with:
    streamlit run src/dikwp_agenttrace/app.py

The CLI is the primary interface and has no runtime dependency on Streamlit.
"""

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None


def main():  # pragma: no cover
    if st is None:
        print("Streamlit is not installed. Use the CLI: dikwp-agenttrace analyze ...")
        return
    st.title("DIKWP AgentTrace OS")
    st.write("Upload an agent run JSON and generate a semantic trace ledger.")
    uploaded = st.file_uploader("Agent run JSON")
    if uploaded:
        st.info("Use the CLI in this prototype for full output generation.")


if __name__ == "__main__":  # pragma: no cover
    main()
