from __future__ import annotations

import argparse
import json
from pathlib import Path

from .analyzer import analyze
from .static_audit import write_audit


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="DIKWP AgentTrace OS")
    sub = parser.add_subparsers(dest="command", required=True)

    p_analyze = sub.add_parser("analyze", help="Analyze an AI agent run log")
    p_analyze.add_argument("input", help="Path to agent run JSON")
    p_analyze.add_argument("--policy", default=None, help="Path to policy JSON")
    p_analyze.add_argument("--out", default="outputs/demo", help="Output directory")

    p_static = sub.add_parser("static-audit", help="Audit source tree for forbidden host capabilities")
    p_static.add_argument("path", help="Path to source tree")
    p_static.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")

    args = parser.parse_args(argv)
    if args.command == "analyze":
        report = analyze(args.input, args.policy, args.out)
        print(json.dumps(report.to_dict(), ensure_ascii=False, indent=2))
        return 0
    if args.command == "static-audit":
        report = write_audit(args.path, args.out)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    parser.error("unknown command")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
