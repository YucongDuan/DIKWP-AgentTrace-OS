from __future__ import annotations

from .models import AgentEvent, DIKWPRecord
from .text_utils import estimate_token_count, redact


def register_event(event: AgentEvent) -> DIKWPRecord:
    content = redact(event.content)
    token_count = estimate_token_count(content)
    D = f"event_type={event.event_type}; actor={event.actor}; token_estimate={token_count}; content={content[:240]}"
    I = _information_layer(event)
    K = _knowledge_layer(event)
    W = _wisdom_layer(event)
    P = _purpose_layer(event)
    R = _reliability_layer(event)
    return DIKWPRecord(event_id=event.event_id, D=D, I=I, K=K, W=W, P=P, R=R)


def _information_layer(event: AgentEvent) -> str:
    if event.event_type == "tool_call":
        return f"proposed_or_actual_tool={event.tool_name or 'unknown'}; input_ref={event.input_ref}; output_ref={event.output_ref}"
    if event.event_type == "retrieval":
        return f"retrieved_context; source={event.metadata.get('source','unknown')}; supports={event.metadata.get('supports','unknown')}"
    if event.event_type == "memory_write":
        return f"memory_update; scope={event.metadata.get('scope','unknown')}; ttl={event.metadata.get('ttl','unknown')}"
    return f"relationship={event.event_type}->trace; time={event.timestamp}"


def _knowledge_layer(event: AgentEvent) -> str:
    mapping = {
        "user_input": "user intent candidate; not yet verified",
        "model_call": "model reasoning/output step; borrowed reliability",
        "retrieval": "RAG context; source-to-claim support must be checked",
        "tool_call": "external action candidate; requires tool boundary and approval context",
        "tool_result": "tool output; borrowed reliability and scope-bound",
        "memory_write": "state persistence candidate; requires purpose, privacy, and TTL governance",
        "final_output": "answer/action proposal; requires evidence and trace custody",
    }
    return mapping.get(event.event_type, "agent event; requires semantic review")


def _wisdom_layer(event: AgentEvent) -> str:
    if event.event_type == "tool_call":
        return "Check reversibility, blast radius, user approval, least privilege, and auditability."
    if event.event_type == "memory_write":
        return "Check privacy, consent, retention, poisoning risk, and purpose limitation."
    if event.event_type == "final_output":
        return "Check unsupported certainty, evidence alignment, action boundary, and residual."
    return "Preserve evidence custody, observer boundary, and rollback path."


def _purpose_layer(event: AgentEvent) -> str:
    purpose = event.metadata.get("purpose") or event.metadata.get("task_purpose") or "not_explicit"
    return f"local_purpose={purpose}; ultimate_purpose=not_assumed"


def _reliability_layer(event: AgentEvent) -> str:
    source = event.metadata.get("source", "local_trace")
    if event.event_type in {"model_call", "tool_result", "retrieval"}:
        return f"Borrowed; source={source}; requires support-scope check"
    if event.event_type == "final_output":
        return "Provisional until checked against Evidence Ledger and replay bundle"
    return f"Trace-local; source={source}; hash-chain custody recommended"
