from __future__ import annotations

import hashlib
import json
from typing import Dict, List

from .models import AgentEvent
from .text_utils import redact


def event_hash(event: AgentEvent, previous_hash: str = "GENESIS") -> str:
    payload = {
        "previous_hash": previous_hash,
        "event_id": event.event_id,
        "timestamp": event.timestamp,
        "event_type": event.event_type,
        "actor": event.actor,
        "tool_name": event.tool_name,
        "content": redact(event.content),
        "metadata": event.metadata,
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def build_hash_chain(events: List[AgentEvent]) -> List[Dict]:
    chain = []
    prev = "GENESIS"
    for event in events:
        h = event_hash(event, prev)
        chain.append({
            "event_id": event.event_id,
            "previous_hash": prev,
            "event_hash": h,
            "event_type": event.event_type,
            "timestamp": event.timestamp,
        })
        prev = h
    return chain


def chain_root(chain: List[Dict]) -> str:
    if not chain:
        return "GENESIS"
    return chain[-1]["event_hash"]
