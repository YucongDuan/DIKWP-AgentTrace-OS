from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class AgentEvent:
    event_id: str
    timestamp: str
    event_type: str
    actor: str
    content: str = ""
    tool_name: Optional[str] = None
    input_ref: Optional[str] = None
    output_ref: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RiskFinding:
    event_id: str
    category: str
    severity: str
    score: float
    reason: str
    recovery: str


@dataclass
class DIKWPRecord:
    event_id: str
    D: str
    I: str
    K: str
    W: str
    P: str
    R: str


@dataclass
class TraceReport:
    system: str
    version: str
    trace_id: str
    decision: str
    risk_score: float
    event_count: int
    risk_count: int
    hash_chain_root: str
    event_type_counts: Dict[str, int]
    risk_category_counts: Dict[str, int]
    purpose_drift_score: float
    evidence_gap_score: float
    tool_overreach_score: float
    memory_risk_score: float
    replayable: bool
    findings: List[RiskFinding]

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["findings"] = [asdict(f) for f in self.findings]
        return data
