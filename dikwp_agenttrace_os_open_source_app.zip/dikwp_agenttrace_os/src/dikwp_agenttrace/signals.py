from __future__ import annotations

from collections import Counter
from typing import Dict, List, Tuple

from .models import AgentEvent, RiskFinding
from .text_utils import INJECTION_PHRASES, UNSUPPORTED_CERTAINTY, DANGEROUS_TOOL_WORDS, SECRET_PATTERNS, contains_any
import re


def detect_risks(events: List[AgentEvent], policy: Dict) -> List[RiskFinding]:
    findings: List[RiskFinding] = []
    approved_tools = set(policy.get("approved_tools", []))
    high_impact_tools = set(policy.get("high_impact_tools", []))

    first_purpose = None
    for event in events:
        text = event.content or ""
        purpose = event.metadata.get("purpose") or event.metadata.get("task_purpose")
        if first_purpose is None and purpose:
            first_purpose = str(purpose).lower()

        inj = contains_any(text, INJECTION_PHRASES)
        if inj:
            findings.append(RiskFinding(event.event_id, "prompt_injection_or_audit_suppression", "high", 0.95,
                                       f"Detected injection/audit-suppression phrases: {', '.join(inj[:4])}",
                                       "Quarantine source, strip instruction authority, require human review, and replay from last clean checkpoint."))

        cert = contains_any(text, UNSUPPORTED_CERTAINTY)
        if cert and event.event_type in {"model_call", "final_output"}:
            findings.append(RiskFinding(event.event_id, "unsupported_certainty", "medium", 0.55,
                                       f"Detected over-certain phrasing: {', '.join(cert[:4])}",
                                       "Downgrade claim, require ProofLedger evidence cards, and preserve residual."))

        for pattern in SECRET_PATTERNS:
            if re.search(pattern, text, flags=re.IGNORECASE):
                findings.append(RiskFinding(event.event_id, "sensitive_data_exposure", "high", 1.0,
                                           "Detected credential-like or secret-like text.",
                                           "Redact, rotate affected credential if real, and block memory persistence."))
                break

        if event.event_type == "tool_call":
            tool = event.tool_name or "unknown"
            if approved_tools and tool not in approved_tools:
                findings.append(RiskFinding(event.event_id, "unapproved_tool", "high", 0.9,
                                           f"Tool '{tool}' is not in approved_tools.",
                                           "Block call or request explicit approval and least-privilege review."))
            tool_words = contains_any(text, DANGEROUS_TOOL_WORDS)
            if tool in high_impact_tools or tool_words:
                approval = str(event.metadata.get("approval", "")).lower()
                if approval not in {"approved", "human_approved"}:
                    findings.append(RiskFinding(event.event_id, "tool_overreach", "high", 0.92,
                                               f"High-impact tool or action without approval. tool={tool}; markers={tool_words[:3]}",
                                               "Pause before execution, request human approval, and reduce blast radius."))

        if event.event_type == "memory_write":
            ttl = event.metadata.get("ttl")
            if ttl in {None, "forever", "permanent", "unbounded"}:
                findings.append(RiskFinding(event.event_id, "unbounded_memory", "medium", 0.65,
                                           "Memory write lacks bounded TTL or retention policy.",
                                           "Require purpose limitation, TTL, deletion path, and MemoryLedger review."))
            if inj:
                findings.append(RiskFinding(event.event_id, "memory_poisoning", "high", 0.95,
                                           "Memory write contains injection-like content.",
                                           "Block memory write and isolate source."))

        if first_purpose and purpose and str(purpose).lower() != first_purpose:
            # Heuristic: if purpose string changes sharply, mark drift.
            if not _small_purpose_shift(first_purpose, str(purpose).lower()):
                findings.append(RiskFinding(event.event_id, "purpose_drift", "medium", 0.6,
                                           f"Purpose shifted from '{first_purpose}' to '{purpose}'.",
                                           "Require P-layer continuity check and user confirmation."))

    # Missing evidence on final output when retrieval exists but no support flag.
    retrievals = [e for e in events if e.event_type == "retrieval"]
    finals = [e for e in events if e.event_type == "final_output"]
    if finals:
        supported = [e for e in retrievals if str(e.metadata.get("supports", "")).lower() in {"true", "yes", "supported"}]
        for f in finals:
            if retrievals and not supported:
                findings.append(RiskFinding(f.event_id, "evidence_gap", "medium", 0.58,
                                           "Final output exists but retrieved sources lack explicit support markers.",
                                           "Run ProofLedger claim-to-evidence audit before publishing."))

    return findings


def _small_purpose_shift(a: str, b: str) -> bool:
    aw = set(a.split())
    bw = set(b.split())
    if not aw or not bw:
        return False
    return len(aw & bw) / max(1, len(aw | bw)) >= 0.5


def summarize_findings(findings: List[RiskFinding]) -> Dict[str, int]:
    return dict(Counter(f.category for f in findings))
