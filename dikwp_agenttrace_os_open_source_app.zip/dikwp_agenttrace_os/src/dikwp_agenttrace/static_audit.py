from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Dict, List

FORBIDDEN_IMPORTS = {
    "socket", "subprocess", "paramiko", "requests", "httpx", "ftplib", "telnetlib",
    "shutil", "multiprocessing", "threading"
}
FORBIDDEN_CALLS = {
    "system", "popen", "exec", "eval", "remove", "unlink", "rmdir", "chmod", "chown"
}


def audit_path(path: str | Path) -> Dict:
    root = Path(path)
    findings: List[Dict] = []
    for py in root.rglob("*.py"):
        try:
            tree = ast.parse(py.read_text(encoding="utf-8"), filename=str(py))
        except SyntaxError as exc:
            findings.append({"file": str(py), "type": "syntax_error", "detail": str(exc)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top = alias.name.split(".")[0]
                    if top in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(py), "type": "forbidden_import", "detail": alias.name})
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    top = node.module.split(".")[0]
                    if top in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(py), "type": "forbidden_import", "detail": node.module})
            elif isinstance(node, ast.Call):
                name = _call_name(node.func)
                if name and name.split(".")[-1] in FORBIDDEN_CALLS:
                    findings.append({"file": str(py), "type": "forbidden_call", "detail": name})
    return {
        "system": "DIKWP AgentTrace OS Static Boundary Audit",
        "pass": not findings,
        "finding_count": len(findings),
        "findings": findings,
        "boundary": "No network, subprocess, host mutation, persistence, or evasion primitives should be present in this prototype."
    }


def write_audit(path: str | Path, out: str | Path) -> Dict:
    report = audit_path(path)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def _call_name(func) -> str:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        base = _call_name(func.value)
        return f"{base}.{func.attr}" if base else func.attr
    return ""
