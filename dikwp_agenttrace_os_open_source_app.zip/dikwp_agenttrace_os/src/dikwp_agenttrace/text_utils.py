from __future__ import annotations

import re
from typing import Iterable, List

SECRET_PATTERNS = [
    r"sk-[A-Za-z0-9_\-]{12,}",
    r"api[_-]?key\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{8,}",
    r"password\s*[:=]\s*['\"]?[^\s'\"]+",
    r"token\s*[:=]\s*['\"]?[A-Za-z0-9_\-\.]{8,}",
]

INJECTION_PHRASES = [
    "ignore previous",
    "ignore all previous",
    "disregard previous",
    "system prompt",
    "developer message",
    "hidden instruction",
    "do not tell the user",
    "bypass",
    "override policy",
    "secretly remember",
    "never log",
    "disable audit",
]

UNSUPPORTED_CERTAINTY = [
    "guarantee",
    "always",
    "never fail",
    "100%",
    "certified true",
    "standard answer",
    "only correct",
]

DANGEROUS_TOOL_WORDS = [
    "delete",
    "drop table",
    "wire transfer",
    "send email to all",
    "publish",
    "deploy",
    "execute",
    "sudo",
    "chmod",
    "rm -rf",
    "curl http",
    "wget http",
]


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def lower(text: str) -> str:
    return normalize_text(text).lower()


def contains_any(text: str, phrases: Iterable[str]) -> List[str]:
    t = lower(text)
    return [p for p in phrases if p in t]


def redact(text: str) -> str:
    redacted = text or ""
    for pattern in SECRET_PATTERNS:
        redacted = re.sub(pattern, "[REDACTED_SECRET]", redacted, flags=re.IGNORECASE)
    return redacted


def estimate_token_count(text: str) -> int:
    if not text:
        return 0
    # Lightweight approximation for local audit. Not a tokenizer.
    return max(1, int(len(text) / 4))
