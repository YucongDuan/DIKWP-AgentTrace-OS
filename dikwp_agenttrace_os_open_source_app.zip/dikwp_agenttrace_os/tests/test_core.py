from pathlib import Path
import json

from dikwp_agenttrace.analyzer import analyze
from dikwp_agenttrace.static_audit import audit_path

ROOT = Path(__file__).resolve().parents[1]


def test_risky_demo_blocks(tmp_path):
    report = analyze(ROOT / "examples" / "sample_agent_run.json", ROOT / "configs" / "default_policy.json", tmp_path)
    assert report.decision == "block_or_human_review_required"
    assert report.risk_score > 0.6
    assert "tool_overreach" in report.risk_category_counts
    assert "prompt_injection_or_audit_suppression" in report.risk_category_counts
    assert (tmp_path / "replay_bundle.json").exists()


def test_clean_demo_allows_or_reviews(tmp_path):
    report = analyze(ROOT / "examples" / "clean_agent_run.json", ROOT / "configs" / "default_policy.json", tmp_path)
    assert report.decision in {"allow", "review"}
    assert report.risk_score < 0.6
    data = json.loads((tmp_path / "agent_trace_report.json").read_text(encoding="utf-8"))
    assert data["replayable"] is True


def test_static_audit_passes():
    report = audit_path(ROOT / "src")
    assert report["pass"] is True
    assert report["finding_count"] == 0
